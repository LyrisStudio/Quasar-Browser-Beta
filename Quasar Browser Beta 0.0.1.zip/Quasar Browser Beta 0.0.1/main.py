import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QLineEdit, QVBoxLayout,
                             QWidget, QPushButton, QHBoxLayout, QTabWidget,
                             QTabBar)
from PyQt6.QtCore import Qt, QUrl, QPoint, QSize
from PyQt6.QtGui import QIcon, QColor, QPainter
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineSettings, QWebEngineProfile


def setup_qt_environment():
    os.environ['QT_QPA_PLATFORM'] = 'xcb'
    os.environ['QTWEBENGINE_CHROMIUM_FLAGS'] = (
        "--ignore-certificate-errors "
        "--disable-features=PermissionsPolicyHeader,ClientHintsFormFactors "
        "--disable-site-isolation-trials"
    )


class TitleBar(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.setFixedHeight(35)
        self.old_pos = None

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 10, 0)
        layout.setSpacing(5)

        # Кнопки управления окном с иконками
        self.minimize_btn = QPushButton()
        self.minimize_btn.setIcon(QIcon('assets/minimise.png'))

        self.maximize_btn = QPushButton()
        self.maximize_btn.setIcon(QIcon('assets/fillscreen.png'))

        self.close_btn = QPushButton()
        self.close_btn.setIcon(QIcon('assets/close.png'))

        # Размер и стиль кнопок
        icon_size = QSize(16, 16)
        btn_style = """
        QPushButton {
            background: transparent;
            border: none;
            padding: 4px;
        }
        QPushButton:hover {
            background: rgba(123, 90, 255, 0.3);
            border-radius: 3px;
        }
        QPushButton:pressed {
            background: rgba(123, 90, 255, 0.5);
        }
        """

        for btn in [self.minimize_btn, self.maximize_btn, self.close_btn]:
            btn.setIconSize(icon_size)
            btn.setFixedSize(25, 25)
            btn.setStyleSheet(btn_style)

        layout.addStretch()
        layout.addWidget(self.minimize_btn)
        layout.addWidget(self.maximize_btn)
        layout.addWidget(self.close_btn)

        # Подключение кнопок
        self.minimize_btn.clicked.connect(self.parent.showMinimized)
        self.maximize_btn.clicked.connect(self.toggle_maximize)
        self.close_btn.clicked.connect(self.parent.close)

    def toggle_maximize(self):
        if self.parent.isMaximized():
            self.parent.showNormal()
            self.maximize_btn.setIcon(QIcon('assets/fillscreen.png'))
        else:
            self.parent.showMaximized()
            self.maximize_btn.setIcon(QIcon('assets/restore.png'))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.old_pos is not None:
            delta = event.globalPosition().toPoint() - self.old_pos
            if not self.parent.isMaximized():
                self.parent.move(self.parent.pos() + delta)
            self.old_pos = event.globalPosition().toPoint()
            event.accept()

    def mouseDoubleClickEvent(self, event):
        self.toggle_maximize()
        event.accept()

    def mouseReleaseEvent(self, event):
        self.old_pos = None

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(40, 30, 70))


class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        setup_qt_environment()

        # Настройка профиля
        profile = QWebEngineProfile.defaultProfile()
        profile.setHttpCacheMaximumSize(0)
        profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)

        self.setWindowTitle("Quasar Browser")
        self.setMinimumSize(800, 600)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # Главный контейнер
        main_widget = QWidget()
        main_widget.setStyleSheet("""
            background: #1e1e2e;
            border-radius: 8px;
            border: 1px solid #7b5aff;
        """)
        self.setCentralWidget(main_widget)

        layout = QVBoxLayout(main_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Панель заголовка
        self.title_bar = TitleBar(self)
        layout.addWidget(self.title_bar)

        # Основное содержимое
        content = QWidget()
        content.setStyleSheet("background: #2a2139; border-radius: 0 0 8px 8px;")
        layout.addWidget(content)

        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(10, 10, 10, 10)
        content_layout.setSpacing(10)

        # Панель инструментов
        toolbar = QHBoxLayout()

        # Кнопки навигации с иконками
        self.back_btn = QPushButton()
        self.back_btn.setIcon(QIcon('assets/back.png'))

        self.forward_btn = QPushButton()
        self.forward_btn.setIcon(QIcon('assets/forward.png'))

        self.refresh_btn = QPushButton()
        self.refresh_btn.setIcon(QIcon('assets/refresh.png'))

        self.home_btn = QPushButton()
        self.home_btn.setIcon(QIcon('assets/home.png'))

        self.new_tab_btn = QPushButton()
        self.new_tab_btn.setIcon(QIcon('assets/newtab.png'))

        # Стиль и размер кнопок
        toolbar_icon_size = QSize(20, 20)
        btn_style = """
        QPushButton {
            background: #3a2e4a;
            border: 1px solid #7b5aff;
            border-radius: 17px;
        }
        QPushButton:hover {
            background: #4a3e5a;
        }
        QPushButton:disabled {
            background: #2a2139;
            border-color: #5a4a8f;
        }
        """

        for btn in [self.back_btn, self.forward_btn, self.refresh_btn, self.home_btn, self.new_tab_btn]:
            btn.setIconSize(toolbar_icon_size)
            btn.setFixedSize(35, 35)
            btn.setStyleSheet(btn_style)

        self.search_bar = QLineEdit()
        self.search_bar.setStyleSheet("""
            QLineEdit {
                background: #2a2139;
                border: 2px solid #7b5aff;
                border-radius: 15px;
                padding: 8px 15px;
                color: #e0d0ff;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #a07bff;
            }
        """)

        toolbar.addWidget(self.back_btn)
        toolbar.addWidget(self.forward_btn)
        toolbar.addWidget(self.refresh_btn)
        toolbar.addWidget(self.home_btn)
        toolbar.addWidget(self.new_tab_btn)
        toolbar.addWidget(self.search_bar)
        content_layout.addLayout(toolbar)

        # Вкладки
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
            }
            QTabBar::tab {
                background: #3a2e4a;
                color: #d0b0ff;
                border: 1px solid #7b5aff;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                padding: 5px 10px;
                margin-right: 2px;
                min-width: 100px;
                max-width: 200px;
            }
            QTabBar::tab:selected {
                background: #5d4d7a;
            }
            QTabBar::tab:hover {
                background: #4a3e5a;
            }
            QTabBar::close-button {
                image: url(:/qtabbar/close);
                subcontrol-position: right;
            }
            QTabBar::close-button:hover {
                background: rgba(255, 85, 85, 0.3);
            }
        """)

        self.add_tab("https://www.google.com", "Новая вкладка")
        content_layout.addWidget(self.tabs)

        # Подключение сигналов
        self.search_bar.returnPressed.connect(self.navigate)
        self.back_btn.clicked.connect(self.go_back)
        self.forward_btn.clicked.connect(self.go_forward)
        self.refresh_btn.clicked.connect(self.refresh)
        self.home_btn.clicked.connect(self.go_home)
        self.new_tab_btn.clicked.connect(lambda: self.add_tab("https://www.google.com", "Новая вкладка"))
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.update_buttons)

    def add_tab(self, url, title):
        browser = QWebEngineView()

        settings = browser.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.ErrorPageEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.AllowRunningInsecureContent, True)

        browser.setUrl(QUrl(url))

        browser.titleChanged.connect(lambda title, browser=browser:
                                     self.update_tab_title(browser, title))
        browser.urlChanged.connect(lambda url, browser=browser:
                                   self.update_url_bar(url, browser))

        index = self.tabs.addTab(browser, title)
        self.tabs.setCurrentIndex(index)
        self.update_buttons()
        return browser

    def update_tab_title(self, browser, title):
        index = self.tabs.indexOf(browser)
        if index != -1:
            self.tabs.setTabText(index, title[:15] + "..." if len(title) > 15 else title)

    def update_url_bar(self, url, browser):
        if browser == self.tabs.currentWidget():
            self.search_bar.setText(url.toString())
            self.search_bar.setCursorPosition(0)

    def close_tab(self, index):
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            if widget:
                widget.deleteLater()
            self.tabs.removeTab(index)

    def navigate(self):
        url = self.search_bar.text().strip()
        if not url:
            return

        if not url.startswith(("http://", "https://")):
            if '.' in url and ' ' not in url:
                url = "https://" + url
            else:
                url = f"https://www.google.com/search?q={url.replace(' ', '+')}"

        current_browser = self.tabs.currentWidget()
        if current_browser:
            current_browser.setUrl(QUrl(url))

    def go_back(self):
        if current := self.tabs.currentWidget():
            current.back()

    def go_forward(self):
        if current := self.tabs.currentWidget():
            current.forward()

    def refresh(self):
        if current := self.tabs.currentWidget():
            current.reload()

    def go_home(self):
        if current := self.tabs.currentWidget():
            current.setUrl(QUrl("https://www.google.com"))

    def update_buttons(self):
        current = self.tabs.currentWidget()
        self.back_btn.setEnabled(current and current.history().canGoBack())
        self.forward_btn.setEnabled(current and current.history().canGoForward())


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    palette = app.palette()
    palette.setColor(palette.ColorRole.Window, QColor(30, 20, 50))
    palette.setColor(palette.ColorRole.WindowText, QColor(220, 210, 255))
    palette.setColor(palette.ColorRole.Base, QColor(40, 30, 70))
    palette.setColor(palette.ColorRole.Text, QColor(220, 210, 255))
    palette.setColor(palette.ColorRole.Button, QColor(60, 40, 100))
    palette.setColor(palette.ColorRole.ButtonText, QColor(220, 210, 255))
    palette.setColor(palette.ColorRole.Highlight, QColor(123, 90, 255))
    app.setPalette(palette)

    window = BrowserWindow()
    window.show()
    sys.exit(app.exec())